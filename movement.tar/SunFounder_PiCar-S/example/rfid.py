import serial
import smbus
import time
import math
import sys

class Sensors():
	
	def __init__(self):
        	self.bus = smbus.SMBus(1)
        	self.arduino = serial.Serial('/dev/ttyACM0', baudrate=9600, timeout=0.1)

	def read_RFID(self):
		c = ""
	    	self.arduino.flushInput()
	    	text = ""
      		#while c != '\n':
      	    		#if self.arduino.available(15) > 0:
      	        c = self.arduino.read(15);
	      	if c == '': print ''
	      	else:
		      	text = c
		      	#print text.strip()
			return text.strip()		

