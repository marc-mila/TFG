from multiprocessing import Queue, Process
from rfid import Sensors
import time

def read_RFID(rfid_queue, sensors):
    i=0
    while i<1:
        tag = sensors.read_RFID()
        rfid_queue.put("rfid-" + tag)
		print ("Insert done")
        i=i+1

if __name__ == "__main__":


    rfid_queue = Queue()

    sensors = Sensors()
    rfid_process = Process(target=read_RFID, args=(rfid_queue, sensors,))

    rfid_process.start()
    if rfid_queue.qsize()>0:
        print (rfid_queue.get())
        rfid_process.terminate()


