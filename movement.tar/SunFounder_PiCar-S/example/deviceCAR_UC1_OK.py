#!/usr/bin/env python
'''
**********************************************************************
* Filename    : deviceCAr_UC1
* Description : line_follewer + Ultra Sonic detection
* Brand       : SunFounder: line_follower.py + ultrasonic_avoidance.py
* Website     : origin:www.sunfounder.com
* Update      : 31-05-2018
**********************************************************************
'''
from SunFounder_Ultrasonic_Avoidance import Ultrasonic_Avoidance
from SunFounder_Line_Follower import Line_Follower
from picar import front_wheels
from picar import back_wheels
from collections import Counter
import time
import socket
import picar
picar.setup()
PORT_IN = 6510
end = False

#REFERENCES = [25,25,25,25,25]
REFERENCES = [200,200,200,200,200]
#REFERENCES = [300,300,300,300,300]
forward_speed = 70
backward_speed = 35
turning_angle = 0
ua = Ultrasonic_Avoidance.Ultrasonic_Avoidance(20)

max_off_track_count = 0

delay = 0.0005
#delay = 1

fw = front_wheels.Front_Wheels(db='config')
bw = back_wheels.Back_Wheels(db='config')
lf = Line_Follower.Line_Follower()

lf.references = REFERENCES
fw.ready()
bw.ready()
fw.turning_max = 45

################ TCP CONNECTION   #######################

class info_recv:
    def __init__(self):
        # instanciamos un objeto para trabajar con el socket
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # fog = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # Con el metodo bind le indicamos que puerto debe escuchar y de que servidor esperar conexiones
        # Es mejor dejarlo en blanco para recibir conexiones externas si es nuestro caso
        self.s.bind(("", PORT_IN))

        # Aceptamos conexiones entrantes con el metodo listen, y ademas aplicamos como parametro
        # El numero de conexiones entrantes que vamos a aceptar
        self.s.listen(1)
        print("Listen Agents by Port:", PORT_IN)

    ###########  CAR RECIVE FROM AGENT  #####################
    def receive_data(self):
        # Recibimos el mensaje, con el metodo recvfrom recibimos datos y como parametro
        # la cantidad de bytes para recibir. decode
        (self.sc, self.addr) = self.s.accept()

        try:
            print('waiting data...')
            data = self.sc.recv(1024).decode('utf-8')
            #print('data received from:', addr[0])
            return  data
        except Exception as ex:
            print('End Data', ex)


def main():
    global turning_angle, end
    off_track_count = 0
    bw.speed = forward_speed
    # original step
    """a_step = 3
    b_step = 10
    c_step = 35
    d_step = 45"""
    a_step = 3
    b_step = 10
    c_step = 35
    d_step = 45

    #bw.forward()
    #bw.backward()
    #time.sleep(1)

    lt_status_now_back = [0,0,1,0,0]

    dist_aux = 0
    step = 0
    count =0
    distance= 20
    max_off_track_count = 0
    off_line = 0
    # stablish US sensor
    for i in range(100):
        lt_status_nowo = lf.read_digital()
        print lt_status_nowo

    while not end:
        # if out of track reduce speed
        if max_off_track_count > 5:
            bw.speed = backward_speed
        else:
            bw.speed = forward_speed

        count=count+1


    # read sensors: line
        #count = Counter()
        #for i in range(1):

        lt_status_nowo = lf.read_digital()

        lt_status_now = list()
        for x in lt_status_nowo:
            if x == 1:
                lt_status_now.append(0)
            else:
                lt_status_now.append(1)

            #count.update([str(lt_status_now)])
        #print count.most_common(1)[0]
        #lt_status_now = eval(count.most_common(1)[0][0])
    # read sensor  US
        # check sesor every 10 times
        """if count == 10 :
            distance = ua.get_distance()
            print "distance: %scm" % distance
            count=0"""

    # line sensor info treatment

        if lt_status_now == [1,1,1,1,1]:
            off_line=off_line+1
            if off_line > 10:
                bw.stop()
                break

            lt_status_now = lt_status_now_back

        #if lt_status_now == [0,0,0,0,0] and not (lt_status_now_back in ([1,0,0,0,0],[0,0,0,0,1])):
		#	lt_status_now = lt_status_now_back

        lt_status_now_back = lt_status_now
        print lt_status_now

    # Angle calculate
        if	lt_status_now == [0,0,1,0,0]:
            step = 0
        elif lt_status_now == [0,1,1,0,0] or lt_status_now == [0,0,1,1,0] or lt_status_now ==[1,1,1,0,0] or lt_status_now == [0,0,1,1,1]:
            step = a_step
        elif lt_status_now == [0,1,0,0,0] or lt_status_now == [0,0,0,1,0]:
            step = b_step
        elif lt_status_now == [1,1,0,0,0] or lt_status_now == [0,0,0,1,1]:
            step = c_step
        elif lt_status_now == [1,0,0,0,0] or lt_status_now == [0,0,0,0,1]:
            step = d_step
        print 'step ='+str(step)
        # Direction calculate
        if	lt_status_now == [0,0,1,0,0]:
            max_off_track_count = 0
            off_line = 0
            turning_angle = int(90 - step)
            #fw.turn(90)
            print "straight_on"
        # turn right
        elif lt_status_now in ([0,1,1,0,0],[0,1,0,0,0],[1,1,0,0,0],[1,0,0,0,0], [1,1,1,0,0]):
            max_off_track_count = 0
            off_line = 0
            turning_angle = int(90 - step)
            print "turn right"
        # turn left
        elif lt_status_now in ([0,0,1,1,0],[0,0,0,1,0],[0,0,0,1,1],[0,0,0,0,1],[0,0,1,1,1]):
            max_off_track_count = 0
            off_line = 0
            turning_angle = int(90 + step)
            print "turn left"
        elif lt_status_now == [0,0,0,0,0]:
            off_line = 0

            max_off_track_count =max_off_track_count+1
            print max_off_track_count
            if max_off_track_count > 35:
                bw.stop()
                time.sleep(0.5)
                while lt_status_now == [0,0,0,0,0]:
                    print 'out of line'

                    bw.speed = backward_speed
                    fw.turn(90)
                    bw.backward()
                    time.sleep(1)
                    # read sensors: line
                    lt_status_nowo = lf.read_digital()

                    lt_status_now = list()
                    for x in lt_status_nowo:
                        if x == 1:
                            lt_status_now.append(0)
                        else:
                            lt_status_now.append(1)
                turning_angle=90
                max_off_track_count=0
           # bw.stop()
            #break
        print 'turn: '+ str(turning_angle)
        fw.turn(turning_angle)
        bw.forward()
        time.sleep(delay)

    # US sensor info treatment

        if (distance > dist_aux / 2 and distance < 100):
            if (distance < 15 and distance > 0):
                # print "obstacle detected"
                bw.stop()
                end = True
                dist_aux = distance
                time.sleep(1)
        else:
            print "distance fora rang"


def destroy():
    bw.stop()
    fw.turn(90)


if __name__ == '__main__':
    try:
        try:
            print "waiting start signal"
            connect = info_recv()
            connect.receive_data()
            main()
            # straight_run()
            fw.turn(90)
        except Exception, e:
            print e
            print 'error try again in 5'
            destroy()
            time.sleep(5)
    except KeyboardInterrupt:
        destroy()
