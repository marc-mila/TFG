from multiprocessing import Queue, Process
from rfid import Sensors
import time

def read_RFID(rfid_list, sensors):
	tag = sensors.read_RFID()
        rfid_list.append(tag)


if __name__ == "__main__":


    rfid_list = []

    sensors = Sensors()
    #rfid_process = Process(target=read_RFID, args=(rfid_queue, sensors,))

    #rfid_process.start()
    read_RFID(rfid_list, sensors)
    
    print rfid_list[0]


